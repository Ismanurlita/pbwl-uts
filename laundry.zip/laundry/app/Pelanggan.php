<?php
namespace App;

class Pelanggan extends DB{
    
    public function __construct(){
        parent::__construct();
    }

    public function index(){
        $sql = "select * from pelanggans";
        $stmt = $this->db->prepare($sql);
        $stmt->execute();

        $data = [];
        while ($rows = $stmt->fetch()){
            $data[] = $rows;    
        }

        return $data;
    }   

    public function insert(){
        $nama = $_POST['nama'];
        $no_telp = $_POST['no_telp'];
        $sql = "INSERT INTO pelanggans VALUES ('', '$nama', '$no_telp')";
        $stmt = $this->db->prepare($sql);
        $stmt->execute();
    }

    public function edit($id){
        $sql = "SELECT * FROM pelanggans WHERE id='$id'";
        $stmt = $this->db->prepare($sql);

        $stmt->execute();
        $row = $stmt->fetch();

        return $row;
    }   

    public function update($id){
        $nama = $_POST['nama'];
        $no_telp = $_POST['no_telp'];
        $sql = "UPDATE pelanggans SET nama = '$nama', no_telp = '$no_telp' WHERE id='$id'";
        $stmt = $this->db->prepare($sql);
        $stmt->execute();
    }

    public function delete(){
        $id = $_POST['id'];
        $sql = "DELETE FROM pelanggans WHERE id='$id'";
        $stmt = $this->db->prepare($sql);
        $stmt->execute();
    }

}