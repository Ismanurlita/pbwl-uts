<?php
namespace App;

class Transaksi extends DB{
    
    public function __construct(){
        parent::__construct();
    }

    public function index(){
        $sql = "SELECT * from transaksis";
        $stmt = $this->db->prepare($sql);
        
        $stmt->execute();
        
        $data = [];
        while ($rows = $stmt->fetch()){
            $data[] = $rows;    
        }
    
        return $data;
    } 
    
    public function getKategori($id){
        $sql = "SELECT * FROM kategoris WHERE id='$id'";
        $stmt = $this->db->prepare($sql);

        $stmt->execute();
        $row = $stmt->fetch();

        return $row;
    } 

    public function getUser($id){
        $sql = "SELECT * FROM users WHERE id='$id'";
        $stmt = $this->db->prepare($sql);

        $stmt->execute();
        $row = $stmt->fetch();

        return $row;
    } 
    
    public function getPelanggan($id){
        $sql = "SELECT * FROM pelanggans WHERE id='$id'";
        $stmt = $this->db->prepare($sql);

        $stmt->execute();
        $row = $stmt->fetch();

        return $row;
    } 

    public function insert(){
        $pelanggan_id = $_POST['pelanggan_id'];
        $kategori_id = $_POST['kategori_id'];
        $status = $_POST['status'];
        $jumlah = $_POST['jumlah'];
        $user_id = $_POST['user_id'];
        
        $get_kategori = "SELECT * FROM kategoris where id='$kategori_id'";
        $kategori = $this->db->prepare($get_kategori);
        
        $kategori->execute();
        $row = $kategori->fetch();

        $total = (int)$jumlah * (int)$row['harga'];
        
        $sql = "INSERT INTO transaksis VALUES ('', '$kategori_id', '$pelanggan_id', '$user_id', '$status', '$jumlah', '$total')";
        $stmt = $this->db->prepare($sql);
     
        $stmt->execute();
    }

    public function edit($id){
        $sql = "SELECT * FROM transaksis WHERE id='$id'";
        $stmt = $this->db->prepare($sql);

        $stmt->execute();
        $row = $stmt->fetch();

        return $row;
    }

    public function update($id){
        $pelanggan_id = $_POST['pelanggan_id'];
        $kategori_id = $_POST['kategori_id'];
        $status = $_POST['status'];
        $jumlah = $_POST['jumlah'];
        $user_id = $_POST['user_id'];

        $sql = "UPDATE transaksis SET kategori_id = '$kategori_id', pelanggan_id = '$pelanggan_id', 
                user_id = '$user_id', status = '$status', jumlah = '$jumlah', total = '$total' WHERE id='$id'";
        $stmt = $this->db->prepare($sql);
        $stmt->execute();
    }

    public function delete(){
        $id = $_POST['id'];
        $sql = "DELETE FROM transaksis WHERE id='$id'";
        $stmt = $this->db->prepare($sql);
        $stmt->execute();
    }

}