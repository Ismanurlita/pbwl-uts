<?php
    require_once "config.php";

    $pelanggan = new App\Pelanggan();
    $row = $pelanggan->edit($_GET['id']);

    if (isset($_POST['simpan'])) {
        $rows = $pelanggan->update($_GET['id']);
        header("location:index.php?page=index_pelanggan");
    }
?>

<div class="container" style="padding-top: 40px">
    <div class="card" style="width: 600px">
        <div class="card-title">Data Pelanggan</div>
        <form method="POST">
            <div class="form-group">
                <label for="">Nama</label>
                <input type="text" name="nama" value="<?php echo $row['nama'] ?>">
            </div>
            <div class="form-group">
                <label for="">No Telp/HP</label>
                <input type="number" name="no_telp" value="<?php echo $row['no_telp'] ?>">
            </div>
            <button class="btn btn-success" name="simpan">Simpan</button>
        </form>
    </div>
</div>