<?php
    require_once "config.php";
    $kategori = new App\Kategori();
    $data_kategori = $kategori->index();
    
    $pelanggan = new App\Pelanggan();
    $data_pelanggan = $pelanggan->index();

    $transaksi = new App\Transaksi();
    $row = $transaksi->edit($_GET['id']);
    
    if (isset($_POST['simpan'])) {
        $transaksi->update($_GET['id']);
        header("location:index.php?page=index_transaksi");
    }
?>

<div class="container" style="padding-top: 40px">
    <div class="card" style="width: 600px">
        <div class="card-title">Data Transaksi</div>
        <form method="POST">
            <div class="form-group">
                <label for="">Nama</label>
                <select name="pelanggan_id" id="">
                    <option value="">-Silahkan Pilih-</option>
                    <?php foreach($data_pelanggan as $item) { ?>
                    <option value="<?php echo $item['id'] ?>"
                        <?php if ($item['id'] == $row['pelanggan_id']) { ?>
                            selected
                        <?php } ?>
                    >
                        <?php echo $item['nama'] ?> - <?php echo $item['no_telp'] ?>
                    </option>
                    <?php } ?>
                </select>
            </div>

            <div class="form-group">
                <label for="">Status</label>
                <select name="status" id="">
                    <option value="">-Silahkan Pilih-</option>
                    <option value="Belum Lunas"
                    <?php if ($row['status'] == 'Belum Lunas') { ?>
                        selected
                    <?php } ?> >Belum Lunas</option>
                    <option value="Lunas"
                    <?php if ($row['status'] == 'Lunas') { ?>
                        selected
                    <?php } ?>
                    >Lunas</option>
                </select>
            </div>

            <div class="form-group">
                <label for="">Kategori</label>
                <select name="kategori_id" id="">
                    <option value="">-Silahkan Pilih-</option>
                    <?php foreach($data_kategori as $item) { ?>
                    <option value="<?php echo $item['id'] ?>"
                        <?php if ($item['id'] == $row['kategori_id']) { ?>
                            selected
                        <?php } ?>
                    ><?php echo $item['nama'] ?></option>
                    <?php } ?>
                </select>
            </div>

            <div class="form-group">
                <label for="">Jumlah Kg</label>
                <input type="number" name="jumlah" value="<?php echo $row['jumlah'] ?>">
            </div>

            <input type="text" style="display: none" name="user_id" value="<?php echo $_SESSION['id'] ?>">
            <button class="btn btn-success" name="simpan">Simpan</button>
        </form>
    </div>
</div>