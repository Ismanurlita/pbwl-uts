<?php
    require_once "config.php";

    $pengguna = new App\Pengguna();
    $row = $pengguna->edit($_GET['id']);

    if (isset($_POST['simpan'])) {
        $rows = $pengguna->update($_GET['id']);
        header("location:index.php?page=index_pengguna");
    }
?>

<div class="container" style="padding-top: 40px">
    <div class="card" style="width: 600px">
        <div class="card-title">Data Pengguna</div>
        <form method="POST">
            <div class="form-group">
                <label for="">Nama</label>
                <input type="text" name="name" value="<?php echo $row['name'] ?>">
            </div>
            <div class="form-group">
                <label for="">Email</label>
                <input type="text" name="email" value="<?php echo $row['email'] ?>">
            </div>
            <div class="form-group">
                <label for="">Password</label>
                <input type="password" name="password">
            </div>
            <button class="btn btn-success" name="simpan">Simpan</button>
        </form>
    </div>
</div>