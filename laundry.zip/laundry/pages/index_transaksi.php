<?php
    require_once "config.php";

    $transaksi = new App\Transaksi();
    $rows = $transaksi->index();

    if (isset($_POST['hapus'])) {
        $transaksi->delete();
        header("location:index.php?page=index_transaksi");
    }
?>

<div class="container" style="padding-top: 40px">
    <div class="card">
        <div class="card-title">Data Transaksi</div>
        <a href="index.php?page=tambah_transaksi">
            <button class="btn btn-success">Tambah</button>
        </a>
        <p></p>
        <table>
            <tr>
                <th>Nama</th>
                <th>Kategori</th>
                <th>Status</th>
                <th>Total</th>
                <th>Aksi</th>
            </tr>
            <?php foreach ($rows as $row) { ?>
            <?php
                $kategori = $transaksi->getKategori($row['kategori_id']);    
                $pelanggan = $transaksi->getPelanggan($row['pelanggan_id']);
            ?>
            <tr>
                <td><?php echo $pelanggan['nama'] ?></td>
                <td><?php echo $kategori['nama'] ?></td>
                <td><?php echo $row['status'] ?></td>
                <td>Rp. <?php echo number_format($row['total']) ?></td>
                <td style="width: 25%">
                <a href="index.php?page=edit_transaksi&id=<?php echo $row['id']?>">
                    <button class="btn btn-warning">Edit</button>
                </a>
                <form method="POST" style="display: inline">
                    <input type="text" name="id" value="<?php echo $row['id'] ?>" style="display:none">
                    <button class="btn btn-danger" name="hapus">Hapus</button>
                </form>
                </td>
            </tr>
            <?php } ?>
        </table>
    </div>
</div>